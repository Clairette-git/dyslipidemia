# DIABETES-PREDICTION-SYTEM-
The main objective of this project is to develop a system for diagnosis of diabetes disease using data mining modeling technique. The system will predict whether a patient is affected with diabetes diseases or not by using Artificial Neural Network machine learning algorithms on a qualified datasets
